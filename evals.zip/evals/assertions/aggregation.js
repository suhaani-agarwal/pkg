"use strict";

module.exports = async (output, context) => {
  if (!context.vars?.aggregation) return { pass: true, score: 1, reason: "n/a" };

  const { groupField, valueField, method, expected_table, threshold_pct = 5 } = context.vars.aggregation;

  // Ground truth: independent raw-row fetch and manual aggregation
  const rawResp = await fetch(process.env.HASURA_ENDPOINT, {
    method: "POST",
    headers: {
      "x-hasura-admin-secret": process.env.HASURA_ADMIN_SECRET,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      query: `query { oracle { t: ${expected_table}(limit: 1000) { ${groupField} ${valueField} } } }`,
    }),
  }).then(r => r.json());

  const rawRows = rawResp.data?.oracle?.t ?? [];
  if (!rawRows.length) {
    return { pass: true, score: 1, reason: "no seeded data in expected_table — skip" };
  }

  // Compute ground truth by grouping raw rows
  const grouped = {};
  for (const row of rawRows) {
    const k = String(row[groupField] ?? "unknown");
    if (!grouped[k]) grouped[k] = [];
    grouped[k].push(Number(row[valueField] ?? 0));
  }
  const groundTruth = Object.fromEntries(
    Object.entries(grouped).map(([k, vals]) => {
      const arr = vals;
      let v;
      if (method === "avg") {
        v = arr.reduce((s, x) => s + x, 0) / arr.length;
      } else if (method === "sum") {
        v = arr.reduce((s, x) => s + x, 0);
      } else if (method === "max") {
        v = Math.max(...arr);
      } else if (method === "min") {
        v = Math.min(...arr);
      } else {
        v = arr.length; // count
      }
      return [k, +v.toFixed(2)];
    })
  );

  // Collect what the LLM actually reported — read from stub results, NEVER from prose text
  const calls = context.metadata?.toolCalls ?? [];
  const queryCall = calls.find(c => c.name === "query_data");
  const presentCall = calls.find(c => c.name === "present_data");
  const dashCall = calls.find(c => c.name === "get_kpi_dashboard");

  const reported = {};

  // From query_data _raw — handles _aggregate query results:
  // oracle.<alias> = { aggregate: { avg: { field: value } } }
  for (const r of queryCall?.result?.results ?? []) {
    const raw = r._raw?.oracle ?? r._raw ?? {};
    for (const [alias, v] of Object.entries(raw)) {
      if (v && typeof v === "object" && "aggregate" in v) {
        const agg = v.aggregate;
        const val = agg?.[method]?.[valueField] ?? agg?.count;
        if (val !== undefined) reported[alias] = +Number(val).toFixed(2);
      }
    }
    // Also check aliases array (multi-alias oracle response)
    for (const a of r.aliases ?? []) {
      const aliasRaw = a._raw?.oracle ?? {};
      for (const [alias, v] of Object.entries(aliasRaw)) {
        if (v && typeof v === "object" && "aggregate" in v) {
          const agg = v.aggregate;
          const val = agg?.[method]?.[valueField] ?? agg?.count;
          if (val !== undefined) reported[alias] = +Number(val).toFixed(2);
        }
      }
    }
  }

  // From present_data _rows (transform-based aggregation produces {label, value} rows)
  for (const row of presentCall?.result?._rows ?? []) {
    const label = row[groupField] ?? row.label;
    const value = row[valueField] ?? row.value;
    if (label !== undefined && value !== undefined) {
      reported[String(label)] = +Number(value).toFixed(2);
    }
  }

  // From get_kpi_dashboard widget _rows
  for (const wr of dashCall?.result?.widget_results ?? []) {
    for (const row of wr._rows ?? []) {
      const label = row[groupField] ?? row.label;
      const value = row[valueField] ?? row.value;
      if (label !== undefined && value !== undefined) {
        reported[String(label)] = +Number(value).toFixed(2);
      }
    }
  }

  if (!Object.keys(reported).length) {
    return {
      pass: false,
      score: 0,
      reason: `no aggregate values found in stub results — LLM likely fetched raw rows without using _aggregate table. For grouped summaries, use ${expected_table}_aggregate`,
    };
  }

  // Compare reported vs ground truth within threshold
  const errs = [];
  for (const [entity, expected] of Object.entries(groundTruth)) {
    const got = reported[entity];
    if (got === undefined) continue;
    const pctErr = Math.abs(got - expected) / (expected || 1) * 100;
    if (pctErr > threshold_pct) {
      errs.push(`${entity}: ground truth=${expected}, stub returned=${got} (${pctErr.toFixed(1)}% off)`);
    }
  }

  return {
    pass: errs.length === 0,
    score: errs.length === 0 ? 1 : 0,
    reason: errs.join("; ") || "aggregates match",
  };
};
