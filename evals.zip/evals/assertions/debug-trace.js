"use strict";

/**
 * Debug assertion — always passes, but formats the full tool call trace
 * as its reason string so it appears in `promptfoo view` and verbose output.
 *
 * Add to any failing case to see exactly what the LLM called:
 *   - type: javascript
 *     value: file://assertions/debug-trace.js
 */
module.exports = (output, context) => {
  const calls = context.metadata?.toolCalls ?? [];

  if (!calls.length) {
    return { pass: true, score: 1, reason: "⚠️ No tool calls in metadata — custom provider not used or metadata not passed" };
  }

  const lines = [];

  for (let i = 0; i < calls.length; i++) {
    const c = calls[i];
    lines.push(`\n─── Round ${i + 1}: ${c.name} ───`);

    if (c.name === "read_skill") {
      lines.push(`  skill: ${c.args?.name}`);
      const content = typeof c.result === "string" ? c.result : JSON.stringify(c.result);
      lines.push(`  returned: ${content.slice(0, 80)}...`);
    }

    if (c.name === "query_data") {
      for (const q of c.args?.queries ?? []) {
        lines.push(`  query[${q.id}]:`);
        lines.push(`    result_path: ${q.result_path ?? "(none)"}`);
        lines.push(`    graphql: ${(q.graphql ?? "").replace(/\s+/g, " ").slice(0, 200)}`);
        const r = (c.result?.results ?? []).find(x => x.id === q.id);
        if (r?.error) lines.push(`    ❌ error: ${r.error}`);
        else if (r?.count !== undefined) lines.push(`    ✓ rows: ${r.count}, columns: ${r.schema?.columns?.join(", ") ?? "?"}`);
        else if (r?.aliases) lines.push(`    ✓ aliases: ${r.aliases.map(a => `${a.path}(${a.count})`).join(", ")}`);
      }
    }

    if (c.name === "present_data") {
      lines.push(`  graphql: ${(c.args?.graphql ?? "").replace(/\s+/g, " ").slice(0, 200)}`);
      lines.push(`  result_path: ${c.args?.result_path ?? "(none)"}`);
      const res = c.result;
      if (res?.gql_errors?.length) lines.push(`  ❌ gql_errors: ${res.gql_errors.join("; ")}`);
      else lines.push(`  ✓ columns: ${(res?.columns ?? []).join(", ") || "(none)"}`);
      for (const m of res?.field_mappings ?? []) {
        const fields = ["label_field","value_field","time_field","group_field","x_field","y_field","series_field"]
          .filter(k => m[k]).map(k => `${k}=${m[k]}`);
        if (fields.length) lines.push(`  layout[${m.type}]: ${fields.join(", ")}`);
      }
    }

    if (c.name === "get_kpi_dashboard") {
      lines.push(`  widgets: ${(c.result?.widget_results ?? []).length}`);
      for (const wr of c.result?.widget_results ?? []) {
        if (wr.gql_error) lines.push(`  ❌ widget[${wr.id}]: ${wr.gql_error}`);
        else lines.push(`  ✓ widget[${wr.id}]: ${wr.columns.join(", ") || "(no cols)"}`);
      }
      for (const f of c.result?.filters ?? []) {
        lines.push(`  filter: $${f.key} (${f.label})`);
      }
    }
  }

  lines.push(`\n─── Final output (first 300 chars) ───`);
  lines.push(String(output).slice(0, 300));

  return { pass: true, score: 1, reason: lines.join("\n") };
};
