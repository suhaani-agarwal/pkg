"use strict";

module.exports = async (output, context) => {
  const calls = context.metadata?.toolCalls ?? [];
  const errors = [];

  // Layer 1: query_data GQL errors (from real server structuredContent)
  const queryCall = calls.find(c => c.name === "query_data");
  const queryResults = queryCall?.result?.structuredContent?.results ?? {};
  for (const [id, r] of Object.entries(queryResults)) {
    if (r.error) errors.push(`[query_data:${id}] ${r.error}`);
  }

  // Layer 2a: present_data errors (real server: isError flag + content text)
  const presentCall = calls.find(c => c.name === "present_data");
  if (presentCall?.result?.isError) {
    const errText = (presentCall.result.content ?? []).find(c => c.type === "text")?.text ?? "unknown error";
    errors.push(`[present_data] ${String(errText).slice(0, 200)}`);
  }

  // Layer 2b: get_kpi_dashboard errors
  const dashCall = calls.find(c => c.name === "get_kpi_dashboard");
  if (dashCall?.result?.isError) {
    const errText = (dashCall.result.content ?? []).find(c => c.type === "text")?.text ?? "unknown error";
    errors.push(`[get_kpi_dashboard] ${String(errText).slice(0, 200)}`);
  }

  // Layer 3a: present_data field mapping cross-reference
  // Columns come from structuredContent (set by the server after fetching).
  // Field mappings come from the LLM's layout args.
  if (presentCall?.args?.layout) {
    const rawCols = new Set(presentCall.result?.structuredContent?.columns ?? []);

    // When a transform is used, the output columns differ from the raw GQL columns.
    const transform = presentCall.args?.transform;
    const transformOutputCols = {
      "count_by": ["label", "value"],
      "sum_by": ["label", "value"],
      "histogram": ["label", "value"],
      "avg_field": ["value"],
      "avg_by": ["label", "value"],
      "top_n": [], // same columns as input
    };
    const effectiveCols = new Set([
      ...rawCols,
      ...(transform && transformOutputCols[transform] ? transformOutputCols[transform] : []),
    ]);

    for (const block of presentCall.args.layout ?? []) {
      for (const fk of ["label_field", "value_field", "group_field", "time_field", "x_field", "y_field", "series_field"]) {
        const fieldName = block[fk];
        if (fieldName && effectiveCols.size > 0 && !effectiveCols.has(fieldName)) {
          const sample = [...effectiveCols].slice(0, 6).join(", ");
          errors.push(`present_data layout[${block.type}].${fk}="${fieldName}" not in fetched columns (${sample})`);
        }
      }
      // stat_row items check
      for (const item of block.items ?? []) {
        const itemField = typeof item === "string" ? item : item?.field;
        if (itemField && effectiveCols.size > 0 && !effectiveCols.has(itemField)) {
          errors.push(`present_data stat_row item field="${itemField}" not in fetched columns`);
        }
      }
    }
  }

  // Layer 4: drift check — view graphql must reference same tables as query_data
  const queryTables = new Set();
  for (const q of queryCall?.args?.queries ?? []) {
    const matches = (q.graphql ?? "").match(/metric_\w+\d+|fleet_vehicles|fleet_trips|telemetry_events|vehicles|trips|drivers/g);
    (matches ?? []).forEach(t => queryTables.add(t));
  }

  const viewGql = presentCall?.args?.graphql ?? "";
  if (viewGql && queryTables.size > 0) {
    for (const t of queryTables) {
      if (!viewGql.includes(t)) {
        errors.push(`Drift: present_data.graphql doesn't reference "${t}" (was in query_data GQL)`);
      }
    }
  }

  return {
    pass: errors.length === 0,
    score: errors.length === 0 ? 1 : 0,
    reason: errors.join(" | ") || "ok",
  };
};
