"use strict";

// For aggregate stat_row cases: verifies each stat_items[].field has a matching
// top-level GQL alias. Missing alias = server can't flatten the value and the
// stat_row will show "—" for that tile.
//
// Also catches: raw row fetch when an aggregate was required.
module.exports = (output, context) => {
  if (!context.vars?.requires_aggregate) return { pass: true, score: 1, reason: "n/a" };

  const calls = context.metadata?.toolCalls ?? [];
  const errors = [];

  const queryCall = calls.find(c => c.name === "query_data");
  const presentCall = calls.find(c => c.name === "present_data");
  const dashCall = calls.find(c => c.name === "get_kpi_dashboard");

  const allGql = (queryCall?.args?.queries ?? []).map(q => q.graphql ?? "").join("\n");

  // Check that aggregate syntax appears when a summary is required
  const needsSummary = context.vars?.data_shape === "single_record" ||
    context.vars?.requires_aggregate === true;

  if (needsSummary && allGql && !allGql.includes("_aggregate") && !allGql.includes("aggregate {")) {
    errors.push(
      "requires_aggregate=true but GQL has no _aggregate table or aggregate { } block — " +
      "raw rows fetched instead of server-side aggregates"
    );
  }

  // present_data: every stat_row item.field must appear as a GQL alias
  if (presentCall) {
    const statLayout = (presentCall.args?.layout ?? []).find(b => b.type === "stat_row");
    if (statLayout) {
      for (const item of statLayout.items ?? []) {
        const field = item.field;
        if (!field) continue;
        // GQL alias pattern: "fieldName :" anywhere in the query
        if (!new RegExp(`\\b${field}\\s*:`).test(allGql)) {
          errors.push(
            `stat_row item field="${field}" has no matching GQL alias — ` +
            `server flattens using alias names so GQL must have "${field}: someTable_aggregate{...}"`
          );
        }
      }
    }
  }

  // get_kpi_dashboard: same check per widget that has stat_items
  if (dashCall) {
    for (const w of dashCall.result?.widgets ?? []) {
      if (!w.stat_items?.length) continue;
      const wGql = w.graphql ?? "";
      for (const item of w.stat_items) {
        const field = item.field;
        if (!field) continue;
        if (!new RegExp(`\\b${field}\\s*:`).test(wGql)) {
          errors.push(
            `[widget:${w.id}] stat_items field="${field}" has no matching GQL alias in widget graphql`
          );
        }
      }
    }
  }

  return {
    pass: errors.length === 0,
    score: errors.length === 0 ? 1 : 0,
    reason: errors.join("; ") || "ok",
  };
};
