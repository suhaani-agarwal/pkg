"use strict";

// Verifies that the LLM read the correct skill(s) before writing GQL and before
// calling view tools. Two rules:
//
//   1. read_skill must be called BEFORE query_data:
//      - oracle GQL → must have read an oracle-* skill
//      - fleet GQL  → must have read schema-pg or schema-index
//
//   2. read_skill("present-data-layouts") must be called BEFORE present_data:
//      Without this, the LLM defaults to plain table, uses wrong block types,
//      and misses the oracle data rule (never plain table for oracle metrics).
module.exports = (output, context) => {
  const calls = context.metadata?.toolCalls ?? [];
  const errors = [];

  const readCalls = calls.filter(c => c.name === "read_skill");
  const queryCall = calls.find(c => c.name === "query_data");
  const presentCall = calls.find(c => c.name === "present_data");

  // ── Rule 1: correct domain skill before query_data ──────────
  if (queryCall) {
    const queryIdx = calls.indexOf(queryCall);
    const readBeforeQuery = readCalls.filter(c => calls.indexOf(c) < queryIdx);
    const skillsRead = readBeforeQuery.map(c => c.args?.name ?? "");

    if (readBeforeQuery.length === 0) {
      errors.push("read_skill never called before query_data — LLM is writing GQL from memory");
    } else {
      const allGql = (queryCall.args?.queries ?? []).map(q => q.graphql ?? "").join("\n");
      const touchesOracle = /\boracle\s*\{|\bmetric_[a-z]+_\d+/.test(allGql);
      const touchesFleet = /\b(vehicles|trips|telemetry_events|drivers)\b/.test(allGql);

      if (touchesOracle && !skillsRead.some(s => /oracle/.test(s))) {
        errors.push(
          `Oracle GQL written but skill read was [${skillsRead.join(", ")}] — must read oracle-graphql or oracle-catalog first`
        );
      }
      if (touchesFleet && !skillsRead.some(s => /schema-pg|schema-index/.test(s))) {
        errors.push(
          `Fleet GQL written but no fleet skill read — must read schema-pg first`
        );
      }
    }
  }

  // ── Rule 2: present-data-layouts before present_data ────────
  if (presentCall) {
    const presentIdx = calls.indexOf(presentCall);
    const readBeforePresent = readCalls.filter(c => calls.indexOf(c) < presentIdx);
    const layoutSkillRead = readBeforePresent.some(c => c.args?.name === "present-data-layouts");

    if (!layoutSkillRead) {
      errors.push(
        "read_skill('present-data-layouts') not called before present_data — " +
        "LLM is constructing layout[] without the layout reference, risking wrong block types " +
        "and missing the oracle data rule (never plain table for oracle metrics)"
      );
    }
  }

  return {
    pass: errors.length === 0,
    score: errors.length === 0 ? 1 : 0,
    reason: errors.join("; ") || "ok",
  };
};
