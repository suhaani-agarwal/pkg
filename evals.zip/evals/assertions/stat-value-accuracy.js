"use strict";

// For stat_row cases with requires_aggregate=true: verifies the flattened aggregate
// values the view would render are:
//   1. Non-null (catches the "—" bug — empty _rows from flattenResult failure)
//   2. Matching an independent Hasura ground-truth fetch (within 1%)
//   3. Covering all fields listed in expected_stat_fields
//
// The stub returns _rows[0] from the actual Hasura response (post-flattenResult),
// so if _rows is empty, flattenResult broke or field names don't match.
module.exports = async (output, context) => {
  if (!context.vars?.requires_aggregate) return { pass: true, score: 1, reason: "n/a" };

  const calls = context.metadata?.toolCalls ?? [];
  const errors = [];

  const presentCall = calls.find(c => c.name === "present_data");
  if (!presentCall) return { pass: true, score: 1, reason: "no present_data call" };

  const statLayout = (presentCall.args?.layout ?? []).find(b => b.type === "stat_row");
  if (!statLayout) return { pass: true, score: 1, reason: "no stat_row block" };

  const rows = presentCall.result?._meta?.rows ?? [];
  const expectedFields = context.vars?.expected_stat_fields ?? [];

  // Check 1: _rows must be non-empty (empty = flattenResult failed or GQL returned nothing)
  if (rows.length === 0) {
    errors.push(
      "stat_row _rows is empty — flattenResult returned no rows. " +
      "This means the aggregate response wasn't flattened correctly or the GQL returned no data. " +
      "The stat_row will show '—' for all values."
    );
    return { pass: false, score: 0, reason: errors.join("; ") };
  }

  const row = rows[0];

  // Check 2: every expected field must exist in the flattened row as a non-null number
  for (const field of expectedFields) {
    const val = row[field];
    if (val === null || val === undefined) {
      errors.push(
        `expected_stat_fields field="${field}" is null/undefined in _rows[0] — ` +
        `stat_row will show "—". Check GQL alias matches: "${field}: table_aggregate{...}"`
      );
    } else if (typeof val !== "number") {
      errors.push(
        `field="${field}" has type ${typeof val} (expected number) — stat_row may render incorrectly`
      );
    }
  }

  // Check 3: every stat_items field must also exist in the row
  for (const item of statLayout.items ?? []) {
    const field = item.field;
    if (!field) continue;
    if (!expectedFields.includes(field) && (row[field] === null || row[field] === undefined)) {
      errors.push(
        `stat_row item field="${field}" is missing from flattened row — will show "—". ` +
        `Row has keys: [${Object.keys(row).join(", ")}]`
      );
    }
  }

  // Check 4: independent ground-truth verification (requires Hasura endpoint in env)
  const hasura = process.env.HASURA_ENDPOINT;
  const secret = process.env.HASURA_ADMIN_SECRET;
  const presentGql = presentCall.args?.graphql;

  if (hasura && secret && presentGql && errors.length === 0) {
    try {
      const resp = await fetch(hasura, {
        method: "POST",
        headers: { "x-hasura-admin-secret": secret, "Content-Type": "application/json" },
        body: JSON.stringify({ query: presentGql, variables: presentCall.args?.variables ?? {} }),
      });
      const json = await resp.json();
      if (!json.errors && json.data) {
        // Flatten the ground-truth response the same way the server would
        const gtRow = flattenAggregateResponse(json.data);
        for (const field of expectedFields) {
          const reported = row[field];
          const groundTruth = gtRow[field];
          if (groundTruth === undefined || groundTruth === null) continue;
          if (typeof reported === "number" && typeof groundTruth === "number") {
            const pctErr = Math.abs(reported - groundTruth) / (Math.abs(groundTruth) || 1) * 100;
            if (pctErr > 1) {
              errors.push(
                `field="${field}" value mismatch: reported=${reported}, ground truth=${groundTruth} (${pctErr.toFixed(1)}% off)`
              );
            }
          }
        }
      }
    } catch (_e) {
      // Ground-truth check is best-effort — don't fail the assertion if Hasura is unreachable
    }
  }

  return {
    pass: errors.length === 0,
    score: errors.length === 0 ? 1 : 0,
    reason: errors.join("; ") || `ok — _rows[0] has keys [${Object.keys(row).join(", ")}]`,
  };
};

// Minimal local flattenAggregateNode — mirrors src/tools/types.ts
function flattenAggregateNode(alias, node) {
  const row = {};
  const agg = node?.aggregate ?? node;
  if (!agg || typeof agg !== "object") return row;
  for (const [fn, fieldOrVal] of Object.entries(agg)) {
    if (fieldOrVal === null || fieldOrVal === undefined) continue;
    if (fn === "count" || fn === "count_distinct") {
      row[alias] = fieldOrVal;
    } else if (typeof fieldOrVal === "object") {
      const nonNull = Object.entries(fieldOrVal).filter(([, v]) => v !== null && v !== undefined);
      if (nonNull.length === 1) {
        row[alias] = nonNull[0][1];
      } else {
        for (const [f, v] of nonNull) row[`${alias}_${f}`] = v;
      }
    }
  }
  return row;
}

function flattenAggregateResponse(data) {
  if (!data || typeof data !== "object") return {};
  // Check all top-level keys for aggregate nodes
  const syntheticRow = {};
  for (const [alias, val] of Object.entries(data)) {
    if (!val || typeof val !== "object" || !("aggregate" in val)) continue;
    Object.assign(syntheticRow, flattenAggregateNode(alias, val));
  }
  // Check one level deep (oracle{} wrapper)
  if (Object.keys(syntheticRow).length === 0) {
    for (const wrapper of Object.values(data)) {
      if (!wrapper || typeof wrapper !== "object") continue;
      for (const [alias, val] of Object.entries(wrapper)) {
        if (!val || typeof val !== "object" || !("aggregate" in val)) continue;
        Object.assign(syntheticRow, flattenAggregateNode(alias, val));
      }
    }
  }
  return syntheticRow;
}
