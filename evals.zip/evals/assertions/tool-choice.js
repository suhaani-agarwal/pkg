"use strict";

module.exports = (output, context) => {
  const calls = context.metadata?.toolCalls ?? [];
  const errors = [];

  // Must call query_data before any view tool
  const queryCall = calls.find(c => c.name === "query_data");
  const viewCall = calls.find(c => c.name === "present_data" || c.name === "get_kpi_dashboard");

  if (!queryCall) {
    errors.push("query_data never called — LLM must fetch data before rendering");
  } else {
    // Oracle namespace enforcement
    for (const q of queryCall.args?.queries ?? []) {
      const gql = q.graphql ?? "";
      const touchesOracle = /\bmetric_[a-z]+_\d+\b/.test(gql) || /\bevents\b/.test(gql);
      if (touchesOracle && !gql.includes("oracle {") && !gql.includes("oracle{")) {
        errors.push(`query[${q.id}]: oracle table queried without oracle{} wrapper`);
      }
      if (touchesOracle && q.result_path && !q.result_path.startsWith("oracle.")) {
        errors.push(`query[${q.id}]: result_path "${q.result_path}" must start with "oracle." for oracle tables`);
      }
    }
  }

  // Expected tool check
  const expectedTool = context.vars?.expected_tool;
  if (expectedTool) {
    if (!viewCall) {
      errors.push(`Expected ${expectedTool} to be called but no view tool was invoked`);
    } else if (viewCall.name !== expectedTool) {
      errors.push(`Expected ${expectedTool}, got ${viewCall.name}`);
    }
  }

  return {
    pass: errors.length === 0,
    score: errors.length === 0 ? 1 : 0,
    reason: errors.join("; ") || "ok",
  };
};
