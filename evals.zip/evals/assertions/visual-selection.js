"use strict";

// Replicates findOrphanFilters logic from src/tools/dashboard-tools.ts
function findOrphanFilters(filters, allWidgetGql) {
  return filters
    .map(f => f.key)
    .filter(key => {
      const occurrences = (allWidgetGql.match(new RegExp(`\\$${key}\\b`, "g")) ?? []).length;
      return occurrences < 2; // must appear as declaration AND in WHERE clause
    });
}

module.exports = (output, context) => {
  const calls = context.metadata?.toolCalls ?? [];
  const errors = [];

  const queryCall = calls.find(c => c.name === "query_data");
  const presentCall = calls.find(c => c.name === "present_data");
  const dashCall = calls.find(c => c.name === "get_kpi_dashboard");

  const allQueryGql = (queryCall?.args?.queries ?? []).map(q => q.graphql ?? "").join("\n");
  const hasAggregateGql = allQueryGql.includes("_aggregate") || allQueryGql.includes("aggregate {");

  // Aggregate enforcement: oracle has _aggregate for every metric table
  // When user asks for a grouped summary (avg/total per group), raw rows double-count
  if (context.vars?.requires_aggregate === true && !hasAggregateGql) {
    errors.push(
      "requires_aggregate=true but LLM fetched raw rows instead of using _aggregate table. " +
      "Oracle exposes metric_xx_aggregate for every table — grouped summaries (avg/total per OEM, per customer, etc.) " +
      "MUST use the _aggregate variant, otherwise one row-per-day is shown per OEM instead of one aggregate per OEM."
    );
  }

  // Layout shape validation (present_data)
  if (presentCall) {
    const dataShape = context.vars?.data_shape;
    for (const b of presentCall.args?.layout ?? []) {
      if (dataShape === "time_series" && b.type === "pie_chart") {
        errors.push(`pie_chart chosen for time_series data — use line_chart, area_chart, or sparkline_table`);
      }
      if (dataShape === "time_series" && b.type === "metric_grid") {
        errors.push(`metric_grid chosen for time_series data — use sparkline_table or line_chart`);
      }
      if (dataShape === "categorical" && b.type === "line_chart" && !b.time_field) {
        errors.push(`line_chart for categorical data without a time axis — use bar_chart`);
      }
      if (dataShape === "single_record" && ["pie_chart", "bar_chart", "line_chart"].includes(b.type)) {
        errors.push(`${b.type} for single-record data — use detail or stat_row`);
      }
    }

    // Blank plot detection: graphql returned 0 rows (chart will be empty)
    if (presentCall.result?.columns?.length === 0 && !presentCall.result?.gql_errors?.length && presentCall.args?.graphql) {
      errors.push("present_data graphql returned 0 rows — chart will be blank");
    }
  }

  // Dashboard widget checks (get_kpi_dashboard)
  if (dashCall) {
    // Blank widget detection
    for (const wr of dashCall.result?.widget_results ?? []) {
      if (!wr.gql_error && wr.columns.length === 0) {
        errors.push(`[widget:${wr.id}] graphql returned no columns — widget will be blank`);
      }
    }

    // Orphan filter check: filter key must appear in ≥2 widget GQL strings (declared + used in WHERE)
    const allWidgetGql = (dashCall.result?.widgets ?? []).map(w => w.graphql ?? "").join("\n");
    const orphanFilters = findOrphanFilters(dashCall.result?.filters ?? [], allWidgetGql);
    for (const key of orphanFilters) {
      errors.push(`Filter "$${key}" declared but never used in any widget WHERE clause — filter will have no effect`);
    }
  }

  return {
    pass: errors.length === 0,
    score: errors.length === 0 ? 1 : 0,
    reason: errors.join("; ") || "ok",
  };
};
