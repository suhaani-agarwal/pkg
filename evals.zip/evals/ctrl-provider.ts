/**
 * Custom promptfoo provider for CTRL MCP eval.
 *
 * Connects to the real running CTRL MCP server via StreamableHTTPClientTransport,
 * lists tools dynamically, and executes them via client.callTool().
 *
 * Requires: npm run dev running on localhost:3000 before eval.
 */
import Anthropic from "@anthropic-ai/sdk";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

const MODEL = "claude-sonnet-4-6";
const MAX_ROUNDS = 8;
const MCP_URL = process.env.MCP_URL ?? "http://localhost:3000/mcp";

const SYSTEM_PROMPT = `You are a data analyst for a fleet management and enrollment operations platform.
Use the available tools to answer the user's request.`;

async function createMcpClient(): Promise<Client> {
  const client = new Client({ name: "eval-client", version: "1.0" }, {});
  const transport = new StreamableHTTPClientTransport(new URL(MCP_URL));
  await client.connect(transport);
  return client;
}

function mcpToolToAnthropic(tool: { name: string; description?: string; inputSchema: any }): Anthropic.Tool {
  return {
    name: tool.name,
    description: tool.description ?? "",
    input_schema: tool.inputSchema as Anthropic.Tool["input_schema"],
  };
}

export default class CtrlProvider {
  private _id: string;

  constructor(options: any) {
    this._id = options?.id ?? "ctrl-provider";
  }

  id(): string {
    return this._id;
  }

  async callApi(
    prompt: string,
    _context: any,
    _options: any,
  ): Promise<{
    output: string;
    metadata: { toolCalls: Array<{ name: string; args: any; result: any }> };
    tokenUsage?: { total: number; prompt: number; completion: number };
  }> {
    let mcpClient: Client | null = null;
    try {
      mcpClient = await createMcpClient();
    } catch (e: any) {
      return {
        output: `[provider: failed to connect to MCP server at ${MCP_URL} — is npm run dev running? Error: ${e.message}]`,
        metadata: { toolCalls: [] },
      };
    }

    try {
      const { tools: mcpTools } = await mcpClient.listTools();
      const anthropicTools: Anthropic.Tool[] = mcpTools.map(mcpToolToAnthropic);

      const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
      const messages: Anthropic.MessageParam[] = [{ role: "user", content: prompt }];
      const toolCallHistory: Array<{ name: string; args: any; result: any }> = [];
      let totalInput = 0;
      let totalOutput = 0;

      for (let round = 0; round < MAX_ROUNDS; round++) {
        const response = await client.messages.create({
          model: MODEL,
          max_tokens: 4096,
          system: SYSTEM_PROMPT,
          tools: anthropicTools,
          messages,
        });

        totalInput += response.usage.input_tokens;
        totalOutput += response.usage.output_tokens;

        const toolUseBlocks = response.content.filter(
          (b): b is Anthropic.ToolUseBlock => b.type === "tool_use",
        );
        const textBlocks = response.content.filter(
          (b): b is Anthropic.TextBlock => b.type === "text",
        );

        if (response.stop_reason !== "tool_use" || toolUseBlocks.length === 0) {
          return {
            output: textBlocks.map((b) => b.text).join(""),
            metadata: { toolCalls: toolCallHistory },
            tokenUsage: {
              total: totalInput + totalOutput,
              prompt: totalInput,
              completion: totalOutput,
            },
          };
        }

        const toolResults: Anthropic.ToolResultBlockParam[] = [];
        for (const block of toolUseBlocks) {
          let mcpResult: any;
          try {
            mcpResult = await mcpClient.callTool({
              name: block.name,
              arguments: block.input as Record<string, unknown>,
            });
          } catch (e: any) {
            mcpResult = {
              content: [{ type: "text", text: `Error calling ${block.name}: ${e.message}` }],
              isError: true,
            };
          }

          // Extract text for LLM consumption
          const textContent = (mcpResult.content ?? [])
            .filter((c: any) => c.type === "text")
            .map((c: any) => c.text)
            .join("\n");

          toolCallHistory.push({ name: block.name, args: block.input, result: mcpResult });
          toolResults.push({
            type: "tool_result",
            tool_use_id: block.id,
            content: textContent || JSON.stringify(mcpResult),
          });
        }

        messages.push({ role: "assistant", content: response.content });
        messages.push({ role: "user", content: toolResults });
      }

      return {
        output: `[provider: max ${MAX_ROUNDS} rounds reached without final text]`,
        metadata: { toolCalls: toolCallHistory },
      };
    } finally {
      await mcpClient.close().catch(() => {});
    }
  }
}
